<?php
/**
 * Handles logic for AJAX operations.
 *
 * @since 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'IBX_WPFomo_Ajax' ) ) {

    class IBX_WPFomo_Ajax {
        /**
         * Primary class constructor.
         *
         * @since 1.0.0
         * @return void
         */
        public function __construct()
        {
            add_action( 'wp_ajax_nopriv_ibx_wpfomo_get_conversions', array( $this, 'get_conversions' ) );
            add_action( 'wp_ajax_ibx_wpfomo_get_conversions', array( $this, 'get_conversions' ) );
            add_action( 'wp_ajax_ibx_wpfomo_toggle_status', array( $this, 'toggle_status' ) );
        }

        public function ajax_headers()
        {
            send_origin_headers();
    		@header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
    		@header( 'X-Robots-Tag: noindex' );
    		send_nosniff_header();
    		nocache_headers();
    		status_header( 200 );
        }

        /**
         * Get conversions.
         *
         * @since 1.0.0
         */
        public function get_conversions()
        {
            self::ajax_headers();

            if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'ibx_fomo_conversion_nonce_front' ) ) {
                return;
            }
            if ( ! isset( $_POST['ids'] ) || empty( $_POST['ids'] ) || ! is_array( $_POST['ids'] ) ) {
                return;
            }

            $ids = $_POST['ids'];
            $data = array();

            foreach ( $ids as $id ) {
                $settings = MetaBox_Tabs::get_metabox_settings( $id );
                $data['config'] = array(
                    'id'                => $id,
                    'initial_delay'     => !empty( $settings->initial_delay ) ? $settings->initial_delay * 1000 : 0,
                    'display_duration'  => !empty( $settings->display_time ) ? $settings->display_time * 1000 : 0,
                    'delay_each'        => !empty( $settings->delay_between ) ? $settings->delay_between * 1000 : 0,
                    'max_per_page'      => absint( $settings->max_per_page ),
                    'loop'              => absint( $settings->loop ),
                    'randomize'         => isset( $settings->randomize ) ? absint( $settings->randomize ) : 0
				);
				
				if ( 'conversion' == $settings->type ) {
					$data['config']['source'] = $settings->conversions_source;
				}

                ob_start();
                include IBX_WPFOMO_DIR . 'includes/frontend-notification.php';
                $content = ob_get_clean();

                $data['content'] = $content;
            }

            echo json_encode($data); die;
        }

        /**
         * Toggle notification status - active/inactive from post columns.
         *
         * @since 1.0.0
         */
        public function toggle_status()
        {
            self::ajax_headers();

            $error = false;

            if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'ibx_wpfomo_toggle_status' ) ) {
                $error = true;
            }

            if ( ! isset( $_POST['post_id'] ) || empty( $_POST['post_id'] ) || ! absint( $_POST['post_id'] ) ) {
                $error = true;
            }

            if ( $error ) {
                echo __('There is an error updating status.', 'ibx-wpfomo');
                die();
            }

            $post_id = absint( $_POST['post_id'] );
            $status = $_POST['status'] == 'active' ? '1' : '0';

            update_post_meta( $post_id, 'ibx_wpfomo_active_check', $status );

            echo 'success';
            die();
        }
    }

    $ibx_wpfomo_ajax = new IBX_WPFomo_Ajax();
}
