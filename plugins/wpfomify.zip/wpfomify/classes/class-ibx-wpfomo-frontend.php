<?php

/**
 * Handles all logices and frontend configuration.
 *
 * @since 1.0.0
 */

 // Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'IBX_WPFomo_Frontend' ) ) {

    class IBX_WPFomo_Frontend {

        public static $active = array();

        public static $is_cookie_set = 0;

        public $notifications_type = array();

        /**
         * Primary class constructor.
         *
         * @since 1.0.0
         * @return void
         */
        public function __construct()
        {
            $this->notifications_type = apply_filters( 'ibx_wpfomo_notifications_type', array('conversion', 'reviews') );

            $this->init_hooks();
        }

        /**
         * Initialize hooks and filters.
         *
         * @since 1.0.0
         * @return void
         */
        public function init_hooks()
        {
            add_action( 'init', array( $this, 'set_cookie' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'load_scripts' ) );
            add_action( 'wp', array( $this, 'get_active_items' ) );
            add_action( 'wp_footer', array( $this, 'maybe_display_items' ) );
        }

        public function set_cookie()
        {
            $cookie_ip = ( isset( $_COOKIE['ibx_wpfomo_ip'] ) ) ? $_COOKIE['ibx_wpfomo_ip'] : '';
            if ( empty( $cookie_ip ) ) {
                $current_ip = $this->get_client_ip();
                setcookie( 'ibx_wpfomo_ip', $current_ip, strtotime('+1 month'), "/" );
                self::$is_cookie_set = 1;
            }
        }

        /**
    	 * Enqueue styles and scripts.
    	 *
    	 * @since 1.0.0
    	 * @return void
    	 */
        public function load_scripts()
        {
            wp_enqueue_style( 'ibx-wpfomo-style', IBX_WPFOMO_URL . 'assets/css/frontend.css', array() );

            wp_enqueue_script( 'jquery-cookie-script', IBX_WPFOMO_URL . 'assets/js/jquery.cookie.js', array('jquery'), '' );
            wp_enqueue_script( 'ibx-wpfomo-script', IBX_WPFOMO_URL . 'assets/js/frontend.js', array('jquery'), '', true );
        }

        /**
    	 * Get all active notifications.
    	 *
    	 * @since 1.0.0
    	 * @return void
    	 */
        public function get_active_items()
        {
            // WP Query arguments.
            $args = array(
                'post_type'         => 'ibx_wpfomo',
                'posts_per_page'    => '-1',
                'meta_query'        => array(
                    array(
                        'key'           => 'ibx_wpfomo_active_check',
                        'value'         => '1',
                        'compare'       => '='
                    )
                )
            );

            // Get the notification posts.
            $posts = get_posts( $args );

            if ( count( $posts ) ) {
                foreach ( $posts as $post ) {
                    self::$active[] = $post->ID;
                }
            }
        }

        /**
         * Render the notification.
         *
         * @since 1.0.0
         * @return void
         */
        public function maybe_display_items()
        {
            // Return if there is no notification.
            if ( empty( self::$active ) ) {
                return;
            }

            $notifications_type = $this->notifications_type;

            // Conversions.
            $conversion_ids = array();

            // Reviews.
            $reviews_ids = array();

            // Do check for page conditions, logged in, etc here.
            foreach ( self::$active as $id ) {
                $settings = MetaBox_Tabs::get_metabox_settings( $id );

                $logged_in = is_user_logged_in();
                $logged_in_meta = $settings->visibility_display;

                // Check logged in condition.
                if ( ( $logged_in && $logged_in_meta == 'logged_out' ) || ( ! $logged_in && $logged_in_meta == 'logged_in' ) ) {
                    continue;
                }

                // check page location.
                $show_on            = $settings->show_on;
                $global_locations   = $settings->global_locations;
                $custom_locations   = $settings->custom_locations;
                $page_urls          = $settings->page_urls;
                $check              = true;

                if ( $show_on == 'selected' ) {

                    if ( ! empty( $global_locations ) && is_array( $global_locations ) ) {
                        $check = MetaBox_Tabs_Location_Rules::check_location( $global_locations );
                    }

                    if ( ! empty( $custom_locations ) && is_array( $custom_locations ) ) {
                        $check = MetaBox_Tabs_Location_Rules::check_location( $custom_locations );
                    }

                    if ( ! empty( $page_urls ) ) {
                        $check = MetaBox_Tabs_Location_Rules::check_url( $page_urls );
                    }
                }
                elseif ( $show_on == 'hide' ) {

                    if ( ! empty( $global_locations ) && is_array( $global_locations ) ) {
                        $matched = MetaBox_Tabs_Location_Rules::check_location( $global_locations );
                        if ( $matched ) {
                            continue;
                        }
                    }

                    if ( ! empty( $custom_locations ) && is_array( $custom_locations ) ) {
                        $matched = MetaBox_Tabs_Location_Rules::check_location( $custom_locations );
                        if ( $matched ) {
                            continue;
                        }
                    }

                    if ( ! empty( $page_urls ) && MetaBox_Tabs_Location_Rules::check_url( $page_urls ) ) {
                        continue;
                    }
                }

                if ( ! $check ) {
                    continue;
                }

                $current_ip = $this->get_client_ip();
                $visitors   = $settings->visibility_visitors;
                $cookie_ip  = ( isset( $_COOKIE['ibx_wpfomo_ip'] ) ) ? $_COOKIE['ibx_wpfomo_ip'] : '';

                // New visitors.
                if ( 'new' == $visitors ) {
                    if ( $cookie_ip == $current_ip && ! self::$is_cookie_set ) {
                        continue;
                    }
                }

                switch ( $settings->type ) {
                    case "fomo_bar":
                        require IBX_WPFOMO_DIR . 'includes/frontend-fomo-bar.php';
                        break;
                    case "conversion":
                        $conversion_ids[] = $id;
                        break;
                    case "reviews":
                        $reviews_ids[] = $id;
                        break;
                    default:
                        break;
                }

                do_action( 'ibx_wpfomo_frontend_render_content', $settings->type, $settings );

                if ( in_array( $settings->type, $notifications_type ) ) : ?>
                <style id="ibx-notification-<?php echo $id; ?>-style">
                    .ibx-notification-popup-<?php echo $id; ?> {
                        <?php if( $settings->background_color ) { ?>
                            background: <?php echo $settings->background_color; ?>;
                        <?php } ?>
                        <?php if( $settings->text_color ) { ?>
                            color: <?php echo $settings->text_color; ?>;
                        <?php } ?>
                        <?php if( $settings->round_corners >= 0 ) { ?>
                            border-radius: <?php echo $settings->round_corners; ?>px;
                        <?php } ?>
                        <?php if( $settings->border >= 0 ) { ?>
                            border-width: <?php echo $settings->border; ?>px;
                            border-style: solid;
                            border-color: <?php echo $settings->border_color; ?>;
                        <?php } ?>

                        <?php
                            $shadow_blur = ( $settings->shadow_blur >= 0 ) ? $settings->shadow_blur . 'px' : '0';
                            $shadow_spread = ( $settings->shadow_spread >= 0 ) ? $settings->shadow_spread . 'px' : '0';
                            $shadow_opacity = !empty( $settings->shadow_opacity ) ? ($settings->shadow_opacity / 100) : 1;
                            $shadow_color = IBX_WPFomo_Helper::hex2rgba( $settings->shadow_color, $shadow_opacity );
                        ?>
                        <?php echo IBX_WPFomo_Helper::render_box_shadow_css( '0', '0', $shadow_blur, $shadow_spread, $shadow_color ); ?>
                    }
                    .ibx-notification-popup-<?php echo $id; ?> .ibx-notification-popup-title,
                    .ibx-notification-popup-<?php echo $id; ?> .ibx-notification-popup-review-name,
                    .ibx-notification-popup-<?php echo $id; ?> .ibx-notification-popup-review-text {
                        <?php if( $settings->link_color ) { ?>
                            color: <?php echo $settings->link_color; ?>;
                        <?php } ?>
                    }
                    .ibx-notification-popup-<?php echo $id; ?> .ibx-notification-popup-rating span {
                        <?php if( $settings->star_color ) { ?>
                            color: <?php echo $settings->star_color; ?>;
                        <?php } ?>
                    }
                    .ibx-notification-popup--<?php echo $id; ?> .ibx-notification-popup-close {
                        <?php if( $settings->text_color ) { ?>
                            color: <?php echo $settings->text_color; ?>;
                        <?php } ?>
                    }
                    .ibx-notification-popup-<?php echo $id; ?> .ibx-notification-popup-img img {
                        <?php if( $settings->img_round_corners >= 0 ) { ?>
                            border-radius: <?php echo $settings->img_round_corners; ?>px;
                        <?php } ?>
                    }
                </style>
                <?php endif;
            }

            if ( ! empty( $conversion_ids ) || ! empty( $reviews_ids ) ) {
                ?>
                <script type="text/javascript">
                    var ibx_fomo = {
                        nonce: '<?php echo wp_create_nonce('ibx_fomo_conversion_nonce_front'); ?>',
                        conversions: <?php echo json_encode( $conversion_ids ); ?>,
                        reviews: <?php echo json_encode( $reviews_ids ); ?>,
                        ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>'
                    };
                </script>
                <?php
            }
        }

        /**
         * Get IP address of the client.
         *
         * @since 1.0.0
         * @return string
         */
        public function get_client_ip() {
            $ipaddress = '';
            if (getenv('HTTP_CLIENT_IP'))
                $ipaddress = getenv('HTTP_CLIENT_IP');
            else if(getenv('HTTP_X_FORWARDED_FOR'))
                $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
            else if(getenv('HTTP_X_FORWARDED'))
                $ipaddress = getenv('HTTP_X_FORWARDED');
            else if(getenv('HTTP_FORWARDED_FOR'))
                $ipaddress = getenv('HTTP_FORWARDED_FOR');
            else if(getenv('HTTP_FORWARDED'))
               $ipaddress = getenv('HTTP_FORWARDED');
            else if(getenv('REMOTE_ADDR'))
                $ipaddress = getenv('REMOTE_ADDR');
            else
                $ipaddress = 'UNKNOWN';
            return $ipaddress;
        }
    }

    $ibx_wpfomo_frontend = new IBX_WPFomo_Frontend();
}
