<?php
/**
 * Class for helper functions.
 *
 * @since 1.0.0
 */
class IBX_WPFomo_Helper {
	static public function get_notification_template( $template, $tags )
	{
		return self::parse_notification_template( $template, $tags );
	}
    /**
     * Replaces tags with their values.
     *
     * @since 1.0.0
     * @param string $msg
     * @param array $tags
     * @return string
     */
    static public function parse_notification_template( $template, $tags )
    {
		$html = $template;

		if ( is_array( $template ) ) {
			$html = '';
			for ( $i = 0; $i < count( $template ); $i++ ) {
				if ( $i == 0 ) {
					$html .= $template[$i];
				}
				if ( $i == 1 ) {
					$html .= '<span class="ibx-notification-popup-title">' . $template[$i] . '</span>';	
				}
				if ( $i == 2 ) {
					$html .= '<small>' . $template[$i] . '</small>';	
				}
			}
		}

		preg_match_all( '/{{([^}]*)}}/', $html, $tags_in_html, PREG_PATTERN_ORDER );

		$actual_tags = array();
		$formatted_tags = array();

		if ( ! empty( $tags_in_html ) ) {
			for ( $i = 0; $i < count( $tags_in_html[1] ); $i++ ) {
				
				$x = explode( '|', $tags_in_html[1][$i] );
				$tag_in_template = '{{' . trim( $tags_in_html[1][$i] ) . '}}';

				if ( is_array( $x ) ) {
					$actual_tag = '{{' . trim( $x[0] ) . '}}';
					if ( ! isset( $x[1] ) ) {
						$x[1] = ' ';
					}
					$actual_tags[ $actual_tag ] = trim( $x[1] );
					$formatted_tags[ $actual_tag ] = $tag_in_template;
				} else {
					$actual_tags[ $tag_in_template ] = '';
					$formatted_tags[ $tag_in_template ] = $tag_in_template;
				}
			}
		}

        foreach ( $tags as $tag => $value ) {
			
			if ( isset( $actual_tags[ $tag ] ) ) {
				
				$variable = explode( ':', $actual_tags[ $tag ] );
				$formatted_value = $value;
				
				switch ( trim( $variable[0] ) ) {
					case 'bold':
						$formatted_value = '<strong>' . $value . '</strong>';
						break;
					case 'italic':
						$formatted_value = '<em>' . $value . '</em>';
						break;
					case 'color':
						$formatted_value = '<span style="color: ' . trim( $variable[1] ) . ';">' . $value . '</span>';
						break;
					case 'bold+color':
						$formatted_value = '<strong style="color: ' . trim( $variable[1] ) . ';">' . $value . '</strong>';
						break;
					case 'italic+color':
						$formatted_value = '<em style="color: ' . trim( $variable[1] ) . ';">' . $value . '</em>';
						break;
					case 'propercase':
						$formatted_value = '<span style="text-transform: capitalize;">' . $value . '</span>';
						break;
					case 'upcase':
						$formatted_value = '<span style="text-transform: uppercase;">' . $value . '</span>';
						break;
					case 'downcase':
						$formatted_value = '<span style="text-transform: lowercase;">' . $value . '</span>';
						break;
					case 'fallback':
						$tmp_val = trim( $variable[1] );
						$tmp_val = str_replace( '[', '', $tmp_val );
						$tmp_val = str_replace( ']', '', $tmp_val );
						$formatted_value = empty( $value ) ? $tmp_val : $value;
						break;
					default:
						break;
				}
				$html = str_replace( $formatted_tags[ $tag ], $formatted_value, $html );
			} else {
				if ( ! is_array( $html ) ) {
					$html = str_replace( $tag, $value, $html );
				}
			}
        }

        $html = str_replace( '\\', '', $html );

        return $html;
    }

    static public function get_timeago_html( $time = false )
    {
        if ( ! $time ) {
            return;
        }

        $time = human_time_diff(strtotime($time), current_time('timestamp'));
        
        ob_start();
        ?>
        <small><?php echo esc_html__( 'About', 'ibx-wpfomo' ) . ' ' . esc_html( $time ) . ' ' . esc_html__( 'ago', 'ibx-wpfomo' ) ?></small>
        <?php
        $time_ago = ob_get_clean();

        return $time_ago;
    }

    /**
     * Fetch image from Gravatar.
     *
     * @since 1.0.0
     * @param string $email
     * @param string $default_img
     * @return string
     */
    static public function get_gravatar_image( $email = '', $default_img = '' )
    {
        if ( ! empty( $email ) ) {
            $email = strtolower( trim( $email ) );
            $gravtar_md5 = md5( $email );
            $gravatar_img = 'https://www.gravatar.com/avatar/' . $gravtar_md5;
            if ( ! empty( $default_img ) ) {
                $gravatar_img .= '?d=' . urlencode( $default_img );
            }
            return $gravatar_img;
        }

        return $default_img;
    }

    /**
     * Get rating stars html.
     *
     * @since 1.0.0
     * @param int $rating
     * @return string
     */
    static public function get_rating_stars( $rating = '' )
    {
        if ( ! $rating || empty( $rating ) ) {
            return;
        }

        $stars = '';

        for ( $i = 0; $i < $rating; $i++ ) {
            $stars .= '<span>&#9734</span>';
        }

        return $stars;
    }

    /**
     * Get fomo types.
     *
     * @since 1.0.0
     * @param string $type
     * @return string|array
     */
    static public function get_notification_types( $type = '' )
    {
        $types = apply_filters( 'ibx_wpfomo_types', array(
            'fomo_bar'      => __('Notification Bar', 'ibx-wpfomo'),
            'conversion'    => __('Conversion', 'ibx-wpfomo'),
            'reviews'       => __('Reviews', 'ibx-wpfomo')
        ) );

        if ( isset( $types[$type] ) ) {
            return $types[$type];
        }

        return $types;
    }

    static public function render_box_shadow_css( $horizontal = '0px', $vertical = '0px', $blur = '0px', $spread = '0px', $color = '#666' )
    {
        ob_start();
        ?>
        -webkit-box-shadow: <?php echo $horizontal; ?> <?php echo $vertical; ?> <?php echo $blur; ?> <?php echo $spread; ?> <?php echo $color; ?>;
        -moz-box-shadow: <?php echo $horizontal; ?> <?php echo $vertical; ?> <?php echo $blur; ?> <?php echo $spread; ?> <?php echo $color; ?>;
        -o-box-shadow: <?php echo $horizontal; ?> <?php echo $vertical; ?> <?php echo $blur; ?> <?php echo $spread; ?> <?php echo $color; ?>;
        box-shadow: <?php echo $horizontal; ?> <?php echo $vertical; ?> <?php echo $blur; ?> <?php echo $spread; ?> <?php echo $color; ?>;
        <?php

        return ob_get_clean();
    }

    /**
     * Hex to Rgba
     */
    static public function hex2rgba( $hex, $opacity )
    {
    	$hex = str_replace( '#', '', $hex );

    	if ( strlen($hex) == 3 ) {
    		$r = hexdec(substr($hex,0,1).substr($hex,0,1));
    		$g = hexdec(substr($hex,1,1).substr($hex,1,1));
    		$b = hexdec(substr($hex,2,1).substr($hex,2,1));
    	} else {
    		$r = hexdec(substr($hex,0,2));
    		$g = hexdec(substr($hex,2,2));
    		$b = hexdec(substr($hex,4,2));
    	}
    	$rgba = array($r, $g, $b, $opacity);

    	return 'rgba(' . implode(', ', $rgba) . ')';
    }

    static public function api_key()
    {
        return md5( home_url() );
	}
	
	static public function display_saved_log( $key )
	{
		if ( isset( $_GET['post'] ) && isset( $_GET['saved_log'] ) ) {
			$post_id = $_GET['post'];
			echo '<div class="notice notice-warning"><pre>';
			print_r( IBX_WPFomo_Admin::get_post_meta( $post_id, $key ) );
			echo '</pre></div>';
		}
	}
}
