<?php
/**
 * Base class that gets extended by all add-on classes.
 * 
 * @since 1.1
 */
abstract class IBX_WPFomo_Addon {
    /**
     * Holds the class object.
     *
     * @since 1.1
     * @var object
     */
    public static $instance;

    /**
     * Holds the error messages.
     *
     * @since 1.1
     * @var array $errors
     */
    public $errors = array();

    /**
	 * A display name for the addon.
	 *
	 * @since 1.1
	 * @var string $name
	 */
    public $name;
    
     /**
	 * A slug for the addon.
	 *
	 * @since 1.1
	 * @var string $slug
	 */
    public $slug;
    
    /**
	 * The addon's directory path.
	 *
	 * @since 1.1
	 * @var string $dir
	 */
	public $dir;

	/**
	 * The addon's directory url.
	 *
	 * @since 1.1
	 * @var string $url
	 */
    public $url;

    /**
     * Primary class constructor.
     *
     * @since 1.1
     */
    public function __construct( $params = array() )
    {
        if ( ! is_array( $params ) || empty( $params ) ) {
            return;
        }

        if ( in_array( $params['slug'], IBX_WPFomo_Addons::$addons ) ) {
            $this->errors[] = sprintf( _x( 'An addon with the slug %s already exists! Please namespace your addon filenames to ensure compatibility with WPFomify.', '%s stands for the addon slug.', 'ibx-wpfomo' ), $params['slug'] );
        }

        $class_info             = new ReflectionClass( $this );
        $class_path             = $class_info->getFileName();
        $dir_path               = dirname( $class_path );
        $this->slug             = $params['slug'];
        $this->name             = $params['name'];

        // We need to normalize the paths here since path comparisons
		// break on Windows because they use backslashes.
		$abspath                    = str_replace( '\\', '/', ABSPATH );
		$wpfomo_dir                 = str_replace( '\\', '/', IBX_WPFOMO_DIR );
		$dir_path                   = str_replace( '\\', '/', $dir_path );
		$stylesheet_directory       = str_replace( '\\', '/', get_stylesheet_directory() );
		$stylesheet_directory_uri   = str_replace( '\\', '/', get_stylesheet_directory_uri() );
		$template_directory         = str_replace( '\\', '/', get_template_directory() );
		$template_directory_uri     = str_replace( '\\', '/', get_template_directory_uri() );

		// Find the right paths.
		if ( is_child_theme() && stristr( $dir_path, $stylesheet_directory ) ) {
			$this->url = trailingslashit( str_replace( $stylesheet_directory, $stylesheet_directory_uri, $dir_path ) );
			$this->dir = trailingslashit( $dir_path );
		} elseif ( stristr( $dir_path, $template_directory ) ) {
			$this->url = trailingslashit( str_replace( $template_directory, $template_directory_uri, $dir_path ) );
			$this->dir = trailingslashit( $dir_path );
		} elseif ( isset( $params['url'] ) && isset( $params['dir'] ) ) {
			$this->url = trailingslashit( $params['url'] );
			$this->dir = trailingslashit( $params['dir'] );
		} elseif ( ! stristr( $dir_path, $wpfomo_dir ) ) {
			$this->url = trailingslashit( str_replace( trailingslashit( $abspath ), trailingslashit( home_url() ), $dir_path ) );
			$this->dir = trailingslashit( $dir_path );
		}

        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     *
     * @since 1.1
     */
    public function init_hooks()
    {
        if ( is_array( $this->errors ) && ! empty( $this->errors ) ) {
            IBX_WPFomo_Admin::$errors = array_merge( IBX_WPFomo_Admin::$errors, $this->errors );
            return;
        }

        add_filter( 'ibx_wpfomo_admin_general_settings', array( $this, 'register_admin_settings' ), 10, 1 );
        add_action( 'ibx_wpfomo_before_metabox_load', array( $this, 'init_fields' ) );
        add_action( 'ibx_wpfomo_admin_meta_scripts', array( $this, 'admin_enqueue_scripts' ) );
        add_action( 'ibx_wpfomo_admin_settings_scripts', array( $this, 'admin_enqueue_scripts' ) );
        add_filter( 'ibx_wpfomo_conversion_data', array( $this, 'add_conversion_data' ), 10, 2 );
    }

    /**
     * Init fields for integration.
     *
     * @since 1.1
     * @return void
     */
    public function init_fields()
    {
        add_filter( 'ibx_wpfomo_field_fomo_type', array( $this, 'hide_fields' ), 10, 1 );
        add_filter( 'ibx_wpfomo_field_conversions_source', array( $this, 'conversion_source' ), 10, 1 );
        add_filter( 'ibx_wpfomo_metabox_fields', array( $this, 'add_fields' ), 10, 1 );
    }

    /**
	 * Should be overridden by subclasses to enqueue
	 * additional css/js using the add_css and add_js methods.
	 *
	 * @since 1.1
	 * @return void
	 */
    public function admin_enqueue_scripts()
    {
    }

    /**
     * Register admin settings.
     *
     * @since 1.1
     * @param array $settings
     * @return array
     */
    public function register_admin_settings( $settings )
    {
        return $settings;
    }

    /**
     * Conversion fields.
     *
     * @since 1.1
     * @return array
     */
	abstract public function fields();
	
	/**
     * Get conversion fields.
     *
     * @since 1.1.2
     * @return array
     */
	private function get_fields()
	{
		$tabs = $this->fields();
		$actual_fields = array();

		foreach ( $tabs as $tab => $sections ) {
			foreach ( $sections as $section => $fields ) {
				$actual_fields = array_merge( $actual_fields, $fields );
			}
		}

		return $actual_fields;
	}

    /**
     * Hide fields when reviews is selected.
     *
     * @since 1.1
     * @param array $data
     * @return array
     */
    public function hide_fields( $data )
    {
        $fields = $this->get_fields();

        // Hide fields from other field types.
        foreach ( $data['options'] as $option_key => $option_val ) {
            if ( $option_key != 'conversion' ) {
                foreach ( $fields as $key => $field ) {
                    $data['hide'][$option_key]['fields'][] = $key;
                }
            }
        }

        return $data;
    }

    /**
     * Add conversion source.
     *
     * @since 1.1
     * @param array $data
     * @return array
     */
    public function conversion_source( $data )
    {
        $data['options'][$this->slug] = $this->name;
        $data['toggle'][$this->slug]['fields'] = array_keys( $this->get_fields() );

        return $data;
    }

    /**
     * Add fields for conversion.
     *
     * @since 1.1
     * @param array $data
     * @return array
     */
    public function add_fields( $data )
    {
        $tabs = $this->fields();

        foreach ( $tabs as $tab => $sections ) {
			foreach ( $sections as $section => $fields ) {
				foreach ( $fields as $key => $field ) {
					if ( ! isset( $data[$tab] ) || ! isset( $data[$tab]['sections'][$section] ) ) {
						continue;
					}
					$data[$tab]['sections'][$section]['fields'][$key] = $field;
				}
			}
        }

        return $data;
    }

    /**
     * Add conversion content.
     *
     * @since 1.1
     * @param array $data
     * @param object $settings
     * @return array
     */
    public function add_conversion_data( $data, $settings )
    {
        if ( $this->slug != $settings->conversions_source ) {
            return $data;
        }

        return $data;
    }
}