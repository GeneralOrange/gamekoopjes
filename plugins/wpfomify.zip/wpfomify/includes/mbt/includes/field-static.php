<span id="<?php echo $id; ?>" class="mbt-static-field"><?php echo $value; ?></span>
