<style id="ibx-notification-popup-preview">
    .ibx-notification-popup {
        <?php if( $settings->background_color ) { ?>
            background: <?php echo $settings->background_color; ?>;
        <?php } ?>
        <?php if( $settings->text_color ) { ?>
            color: <?php echo $settings->text_color; ?>;
        <?php } ?>
        <?php if( $settings->round_corners >= 0 ) { ?>
            border-radius: <?php echo $settings->round_corners; ?>px;
        <?php } ?>
        <?php if( $settings->border >= 0 ) { ?>
            border-width: <?php echo $settings->border; ?>px;
            border-style: solid;
            border-color: <?php echo $settings->border_color; ?>;
        <?php } ?>

        <?php
            $shadow_blur = ( $settings->shadow_blur >= 0 ) ? $settings->shadow_blur . 'px' : '0';
            $shadow_spread = ( $settings->shadow_spread >= 0 ) ? $settings->shadow_spread . 'px' : '0';
            $shadow_opacity = !empty( $settings->shadow_opacity ) ? ($settings->shadow_opacity / 100) : 1;
            $shadow_color = IBX_WPFomo_Helper::hex2rgba( $settings->shadow_color, $shadow_opacity );
        ?>
        <?php echo IBX_WPFomo_Helper::render_box_shadow_css( '0', '0', $shadow_blur, $shadow_spread, $shadow_color ); ?>
    }
    .ibx-notification-popup .ibx-notification-popup-rating span {
        <?php if( $settings->star_color ) { ?>
            color: <?php echo $settings->star_color; ?>;
        <?php } ?>
    }
    .ibx-notification-popup .ibx-notification-popup-close {
        <?php if( $settings->text_color ) { ?>
            color: <?php echo $settings->text_color; ?>;
        <?php } ?>
    }
    .ibx-notification-popup .ibx-notification-popup-img img {
        <?php if( $settings->img_round_corners >= 0 ) { ?>
            border-radius: <?php echo $settings->img_round_corners; ?>px;
        <?php } ?>
	}
	.ibx-notification-popup small {
		font-size: 10px;
	}
</style>
<div class="ibx-notification-popup ibx-notification-type-<?php echo $settings->type; ?>">
    <span class="ibx-notification-preview-text"><?php _e('Preview', 'ibx-wpfomo'); ?></span>
    <div class="ibx-notification-popup-wrapper">
        <p class="ibx-notification-popup-close" title="<?php esc_html_e('Close', 'ibx-wpfomo'); ?>">×</p>
        <div class="ibx-notification-popup-content">
            <div class="ibx-notification-popup-img">
                <img src="<?php echo IBX_WPFOMO_URL . 'assets/img/placeholder-300x300.png'; ?>" alt="">
            </div>
            <div class="ibx-notification-popup-text type-conversion">
                <?php _e('John D. just purchased', 'ibx-wpfomo'); ?>
				<span class="ibx-notification-popup-title"><?php _e('Your Product Title', 'ibx-wpfomo'); ?></span>
				<small>About 1 hour ago</small>
            </div>
            <div class="ibx-notification-popup-text type-reviews">
                <span class="ibx-notification-popup-review-text"><?php _e('Awesome product!', 'ibx-wpfomo'); ?></span>
                <span class="ibx-notification-popup-review-name">- <?php _e('John Doe', 'ibx-wpfomo'); ?></span>
				<div class="ibx-notification-popup-rating"><span>&#9734</span><span>&#9734</span><span>&#9734</span><span>&#9734</span><span>&#9734</span></div>
				<small>About 1 hour ago</small>
			</div>
        </div>
    </div>
</div>
