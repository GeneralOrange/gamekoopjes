<?php
    $is_closable = $settings->closable;
    $countdown = '';
    if ( isset( $settings->countdown_time['days'] ) && ! empty( $settings->countdown_time['days'] ) ) {
        $countdown .= $settings->countdown_time['days'] . ',';
    } else {
        $countdown .= '00,';
    }
    if ( isset( $settings->countdown_time['hours'] ) && ! empty( $settings->countdown_time['days'] ) ) {
        $countdown .= $settings->countdown_time['hours'] . ',';
    } else {
        $countdown .= '00,';
    }
    if ( isset( $settings->countdown_time['minutes'] ) && ! empty( $settings->countdown_time['days'] ) ) {
        $countdown .= $settings->countdown_time['minutes'] . ',';
    } else {
        $countdown .= '00,';
    }
    if ( isset( $settings->countdown_time['seconds'] ) && ! empty( $settings->countdown_time['days'] ) ) {
        $countdown .= $settings->countdown_time['seconds'];
    } else {
        $countdown .= '00';
    }

    $attrs = ' data-fomo-id="' . $id . '"';
    $attrs .= ' data-initial-delay="' . $settings->initial_delay . '"';
    if ( $settings->auto_hide ) {
        $attrs .= ' data-display-duration="' . $settings->display_time . '"';
    }

?>

<div class="ibx-fomo ibx-fomo-<?php echo $id; ?> ibx-fomo-position-<?php echo $settings->position_fomo_bar; ?><?php echo $settings->enable_countdown ? ' ibx-fomo-countdown-enabled' : ''; ?>" id="ibx-fomo-<?php echo $id; ?>"<?php echo $attrs; ?>>
    <div class="ibx-fomo-bar-wrapper">

        <div class="ibx-fomo-bar-content">

            <?php if ( $is_closable ) : ?>
            <p class="ibx-fomo-bar-close" title="<?php esc_html_e('Close', 'ibx-wpfomo'); ?>">×</p>
            <?php endif; ?>

            <?php if ( $settings->enable_countdown ) : ?>
                <div class="ibx-fomo-countdown-text"><?php echo $settings->countdown_text; ?></div>
                <div class="ibx-fomo-countdown-wrapper">
                    <div class="ibx-fomo-countdown" data-fomo-time="<?php echo $countdown; ?>">
                        <div id="ibx-fomo-countdown-time">
                            <div class="ibx-fomo-countdown-time-col">
                                <span class="ibx-fomo-days">00</span>
                                <span class="ibx-fomo-countdown-time-text"><?php esc_html_e('Days', 'ibx-wpfomo'); ?></span>
                            </div>
                            <div class="ibx-fomo-countdown-time-col">
                                <span class="ibx-fomo-hours">00</span>
                                <span class="ibx-fomo-countdown-time-text"><?php esc_html_e('Hrs', 'ibx-wpfomo'); ?></span>
                            </div>
                            <div class="ibx-fomo-countdown-time-col">
                                <span class="ibx-fomo-minutes">00</span>
                                <span class="ibx-fomo-countdown-time-text"><?php esc_html_e('Mins', 'ibx-wpfomo'); ?></span>
                            </div>
                            <div class="ibx-fomo-countdown-time-col">
                                <span class="ibx-fomo-seconds">00</span>
                                <span class="ibx-fomo-countdown-time-text"><?php esc_html_e('Secs', 'ibx-wpfomo'); ?></span>
                            </div>
                            <span class="ibx-fomo-expired-text"><?php esc_html_e('Expired!', 'ibx-wpfomo'); ?></span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="ibx-fomo-bar-text">
                <?php echo html_entity_decode( $settings->fomo_desc ); ?>
                <?php if ( ! empty( $settings->button_text ) && ! empty( $settings->button_url ) ) : ?>
                    <a href="<?php echo $settings->button_url; ?>" class="ibx-fomo-bar-button"><?php echo $settings->button_text; ?></a>
                <?php endif; ?>
            </div>

        </div>

    </div>
</div>

<style id="ibx-fomo-<?php echo $id; ?>-style">
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper {
        background: <?php if ( $settings->background_color != '' ) { echo $settings->background_color; } else { echo '#ffffff'; } ?>;
        color: <?php if ( $settings->text_color != '' ) { echo $settings->text_color; } else { echo '#000000'; } ?>;
        position: <?php if ( $settings->sticky == 1 ) { echo 'fixed'; } else { echo 'absolute'; } ?>;
    }
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper .ibx-fomo-bar-clickable .ibx-fomo-bar-text {
        <?php if ( $settings->text_color != '' ) { echo 'color: ' . $settings->text_color; } ?>;
    }
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper .ibx-fomo-countdown-wrapper {
        color: <?php if ( $settings->countdown_text_color != '' ) { echo $settings->countdown_text_color; } else { echo '#ffffff'; } ?>;
    }
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper .ibx-fomo-countdown-wrapper #ibx-fomo-countdown-time .ibx-fomo-countdown-time-col {
        background: <?php if ( $settings->countdown_background_color != '' ) { echo $settings->countdown_background_color; } else { echo '#ff0000'; } ?>;
    }
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper {
        border-bottom: <?php if ( $settings->border != '' ) { echo ( $settings->border ).'px'; } else { echo '0px'; } ?> solid <?php if ( $settings->border_color != '' ) { echo ( $settings->border_color ) ; } else { echo '#000'; } ?>;

        <?php
            $shadow_blur = ( $settings->shadow_blur >= 0 ) ? $settings->shadow_blur . 'px' : '0';
            $shadow_spread = ( $settings->shadow_spread >= 0 ) ? $settings->shadow_spread . 'px' : '0';
            $shadow_opacity = !empty( $settings->shadow_opacity ) ? ($settings->shadow_opacity / 100) : 1;
            $shadow_color = IBX_WPFomo_Helper::hex2rgba( $settings->shadow_color, $shadow_opacity );
        ?>
        <?php echo IBX_WPFomo_Helper::render_box_shadow_css( '0', '0', $shadow_blur, $shadow_spread, $shadow_color ); ?>
    }
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper .ibx-fomo-bar-button {
        <?php if ( ! empty( $settings->button_bg_color ) ) { ?>
            background: <?php echo $settings->button_bg_color; ?>;
            background-color: <?php echo $settings->button_bg_color; ?>;
        <?php } ?>
        <?php if ( ! empty( $settings->button_text_color ) ) { ?>
            color: <?php echo $settings->button_text_color; ?>;
        <?php } ?>
        <?php if ( $settings->button_border >= 0 ) { ?>
            border-width: <?php echo $settings->button_border; ?>px;
            border-style: solid;
        <?php } ?>
        <?php if ( ! empty( $settings->button_border_color ) ) { ?>
            border-color: <?php echo $settings->button_border_color; ?>;
        <?php } ?>
        <?php if ( $settings->button_border_radius >= 0 ) { ?>
            border-radius: <?php echo $settings->button_border_radius; ?>px;
        <?php } ?>
    }
    <?php echo '#ibx-fomo-' . $id; ?> .ibx-fomo-bar-wrapper .ibx-fomo-bar-button:hover {
        <?php if ( ! empty( $settings->button_bg_hover_color ) ) { ?>
            background: <?php echo $settings->button_bg_hover_color; ?>;
            background-color: <?php echo $settings->button_bg_hover_color; ?>;
        <?php } ?>
        <?php if ( ! empty( $settings->button_text_hover_color ) ) { ?>
            color: <?php echo $settings->button_text_hover_color; ?>;
        <?php } ?>
        <?php if ( ! empty( $settings->button_border_hover_color ) ) { ?>
            border-color: <?php echo $settings->button_border_hover_color; ?>;
        <?php } ?>
    }

</style>
