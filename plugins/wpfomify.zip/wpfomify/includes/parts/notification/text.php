<?php
	$tags = array();
	$title = '';

	if ( ! empty( $value['title'] ) && ! is_array( $template ) ) {
		$title = '<span class="ibx-notification-popup-title">' . $value['title'] . '</span>';
	}

	foreach ( $value as $tag => $val ) {
		$tags[ '{{' . $tag . '}}' ] = $val;
		if ( $tag == 'title' && ! empty( $title ) ) {
			$tags[ '{{' . $tag . '}}' ] = $title;
		}
	}

	if ( 'conversion' == $type ) {}

	if ( 'reviews' == $type ) {

		$rating = '';
		
		$review_name = '<span class="ibx-notification-popup-review-name">' . $value['name'] . '</span>';

		if ( isset( $value['rating'] ) && $value['rating'] != '' ) {
			$stars = IBX_WPFomo_Helper::get_rating_stars( $value['rating'] );
			$rating = '<div class="ibx-notification-popup-rating">' . $stars . '</div>';
		}

		$tags[ '{{name}}' ] = $review_name;
		$tags[ '{{rating}}' ] = $rating;
	}

	do_action( 'ibx_wpfomo_notification_content', $settings );

	echo IBX_WPFomo_Helper::get_notification_template( $template, $tags );
?>

<?php if ( '1' != get_option( 'ibx_wpfomo_credit_link_disable' ) ) : ?>

	<small class="ibx-wpfomo-branding">
		<svg width="7" height="13" viewBox="0 0 7 13" xmlns="http://www.w3.org/2000/svg" title="<?php _e('Powered by', 'ibx-wpfomo'); ?> WPfomify"><g fill="none" fill-rule="evenodd"><path d="M4.127.496C4.51-.12 5.37.356 5.16 1.07L3.89 5.14H6.22c.483 0 .757.616.464 1.044l-4.338 6.34c-.407.595-1.244.082-1.01-.618L2.72 7.656H.778c-.47 0-.748-.59-.48-1.02L4.13.495z" fill="#F6A623"></path><path fill="#FEF79E" d="M4.606.867L.778 7.007h2.807l-1.7 5.126 4.337-6.34H3.16"></path></g></svg>
		<?php _e('by', 'ibx-wpfomo'); ?> <a href="https://wpfomify.com/?utm_source=<?php echo urlencode(home_url()); ?>&utm_medium=widget_referrer" target="_blank">WPfomify</a>
	</small>
	
<?php endif; ?>