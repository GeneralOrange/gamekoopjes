<?php
if ( isset( $value['image'] ) && isset( $value['image']['url'] ) && ! empty( $value['image']['url'] ) ) {
	$img = $value['image']['url'];
}
elseif ( $settings->customer_avatar && ! empty( $value['email'] ) ) {
	$img = get_avatar_url( $value['email'], array( 'default' => $default_img ) );
}
else {
	$img = $default_img;
}

$img = apply_filters( 'ibx_wpfomo_notification_image_url', $img );

if ( ! empty( $img ) ) : ?>
	<div class="ibx-notification-popup-img">
		<img src="<?php echo $img; ?>" alt="" />
	</div>
<?php endif; ?>