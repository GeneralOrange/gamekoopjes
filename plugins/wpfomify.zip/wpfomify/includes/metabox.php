<?php
function ibx_wpfomo_metabox_args()
{
    return array(
        'id'            => 'ibx-wpfomo',
        'title'         => __('WPfomify', 'ibx-wpfomo'),
        'object_types'  => array('ibx_wpfomo'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_header'   => false,
        'fields_prefix' => 'ibx_wpfomo_',
        'tabs'        => apply_filters( 'ibx_wpfomo_metabox_fields', array(
            'configuration' => array(
                'title'         => __('Config', 'ibx-wpfomo'),
                'sections'      => array(
                    'config'        => array(
                        'title'             => __('Configuration', 'ibx-wpfomo'),
                        'fields'            => array(
                            'active_check'      => array(
                                'type'              => 'checkbox',
                                'label'             => __('Active?', 'ibx-wpfomo'),
                                'default'           => '1',
                                'sanitize'          => false,
                                'description'       => __('If checked, this will activate the notification.', 'ibx-wpfomo'),
                            ),
                            'type'  => apply_filters( 'ibx_wpfomo_field_fomo_type', array(
                                'type'      => 'select',
                                'label'     => __('Type' , 'ibx-wpfomo'),
                                'default'   => 'fomo_bar',
                                'options'   => IBX_WPFomo_Helper::get_notification_types(),
                                'toggle'  => array(
                                    'fomo_bar'   => array(
                                        'sections'  => array('countdown', 'button_style'),
                                        'fields'    => array('fomo_desc', 'sticky', 'button_text', 'button_url', 'position_fomo_bar', 'text_color', 'background_color', 'countdown_text_color', 'countdown_background_color', 'auto_hide', 'initial_delay', 'display_time', 'closable'),
                                    ),
                                    'conversion' => array(
                                        'sections'  => array( 'image_option'),
                                        'fields'    => array( 'conversions_source', 'position', 'text_color', 'background_color', 'link_color', 'round_corners', 'img_round_corners', 'max_per_page', 'delay_between', 'random', 'closable', 'loop', 'randomize', 'link_target', 'initial_delay', 'display_time' )
                                    ),
                                    'reviews' => array(
                                        'sections'  => array( 'image_option'),
                                        'fields'    => array( 'review_template', 'reviews_group', 'position', 'text_color', 'background_color', 'round_corners', 'img_round_corners', 'star_color', 'max_per_page', 'delay_between', 'random', 'closable', 'loop', 'randomize', 'link_target', 'initial_delay', 'display_time' )
                                    ),
                                ),
                                'hide'  => array(
                                    'fomo_bar'   => array(
                                        'fields'    => array('notification_msg', 'conversion_group')
                                    ),
                                    'reviews'   => array(
                                        'fields'    => array('notification_msg', 'conversion_group')
                                    )
                                )
                            ) ),
                        ),
                    ),
                    'image_option'    => array(
                        'title'             => __('Image Options', 'ibx-wpfomo'),
                        'fields'            => array(
                            'customer_avatar' => array(
                                'type'          => 'checkbox',
                                'label'         => __('Use customer avatar as image', 'ibx-wpfomo'),
                                'description'   => __('This requires a customer email address.', 'ibx-wpfomo'),
                            ),
                            'disable_img' => array(
                                'type'          => 'checkbox',
                                'label'         => __('Force Disable Images', 'ibx-wpfomo'),
                                'default'           => '0',
                                'sanitize'          => false,
                                'description'       => __('If checked, it will not display any images in notification.', 'ibx-wpfomo'),
                            ),
                            'default_img_url' => array(
                                'type'          => 'photo',
                                'label'         => __('Default Image URL', 'ibx-wpfomo'),
                                'description'   => __('Upload an image or paste external URL of image.', 'ibx-wpfomo'),
                                'help'          => __('Default images are \'backup\' images for new notification. If an image is provided, it will override the default.', 'ibx-wpfomo'),
                            ),
                        ),
                    ),
                ),
            ),
            'content'    => array(
                'title'     => __('Content', 'ibx-wpfomo'),
                'sections'  => array(
                    'content_section'  => array(
                        'title'             => __('Content', 'ibx-wpfomo'),
                        'fields'            => array(
                            'conversions_source' => apply_filters( 'ibx_wpfomo_field_conversions_source', array(
                                'type'              => 'select',
                                'label'             => __('Source', 'ibx-wpfomo'),
                                'default'           => 'custom',
                                'options'           => array(
                                    'custom'            => __('Custom', 'ibx-wpfomo'),
                                ),
                                'toggle'        => array(
                                    'custom'        => array(
                                        'fields'        => array('notification_msg', 'conversion_group')
                                    )
                                )
                            ) ),
                            'notification_msg'  => array(
                                'type'              => 'textarea',
                                'label'             => __('Notification Template', 'ibx-wpfomo'),
                                'rows'              => 3,
                                'default'           => __('{{name}} from {{city}} just signed up for our newsletter!', 'ibx-wpfomo'),
                                'help'              => __('Variables: {{name}}, {{city}}, {{state}}, {{country}}, {{title}}', 'ibx-wpfomo'),
                                'sanitize'          => false
                            ),
                            'review_template'   => array(
                                'type'              => 'textarea',
                                'label'             => __('Review Template', 'ibx-wpfomo'),
                                'rows'              => 3,
                                'default'           => __('{{title}} {{name}}', 'ibx-wpfomo'),
                                'help'              => __('Variables: {{title}}, {{rating}}, {{name}}', 'ibx-wpfomo'),
                                'sanitize'          => false
                            ),
                            'fomo_desc'   => array(
                                'type'          => 'editor',
                                'label'         => '',
                                'placeholder'   => __('Content you want to display in fomo bar.', 'ibx-wpfomo'),
                                'rows'          => 3,
                                'sanitize'      => false,
                                'media_buttons' => false
                            ),
                            'sticky'            => array(
                                'type'              => 'checkbox',
                                'label'             => __('Sticky Bar?', 'ibx-wpfomo'),
                                'default'           => '0',
                                'sanitize'          => false,
                                'description'       => __('If checked, this will fixed Fomo Bar on the top.', 'ibx-wpfomo'),
                            ),
                            'button_text'         => array(
                                'type'              => 'text',
                                'label'             => __('Button Text', 'ibx-wpfomo'),
                                'default'           => '',
                            ),
                            'button_url'          => array(
                                'type'              => 'text',
                                'label'             => __('Button URL', 'ibx-wpfomo'),
                                'default'           => '',
                            ),
                            'conversion_group'        => array(
                                'type'              => 'group',
                                'title'             => __('Conversion', 'ibx-wpfomo'),
                                'fields'            => array(
                                    'title'              => array(
                                        'type'          => 'text',
                                        'label'         => __('Title', 'ibx-wpfomo'),
                                        'default'       => '',
                                    ),
                                    'name'              => array(
                                        'type'          => 'text',
                                        'label'         => __('Name', 'ibx-wpfomo'),
                                        'default'       => '',
                                    ),
                                    'email'           => array(
                                        'type'          => 'text',
                                        'label'         => __('Email Address', 'ibx-wpfomo'),
                                    ),
                                    'city'           => array(
                                        'type'          => 'text',
                                        'label'         => __('City', 'ibx-wpfomo'),
                                    ),
                                    'state'           => array(
                                        'type'          => 'text',
                                        'label'         => __('State', 'ibx-wpfomo'),
                                    ),
                                    'country'           => array(
                                        'type'          => 'text',
                                        'label'         => __('Country', 'ibx-wpfomo'),
                                    ),
                                    'image'         => array(
                                        'type'          => 'photo',
                                        'label'         => __('Image', 'ibx-wpfomo'),
                                        'help'          => __('Use this field to override the image settings defined under Config tab -> Image Options.', 'ibx-wpfomo')
                                    ),
                                    'url'               => array(
                                        'type'              => 'text',
                                        'label'             => __('URL', 'ibx-wpfomo'),
                                        'default'           => '',
                                    ),
                                ),
                            ),
                            'reviews_group'     => array(
                                'type'              => 'group',
                                'title'             => __('Review', 'ibx-wpfomo'),
                                'fields'            => array(
                                    'title'              => array(
                                        'type'          => 'text',
                                        'label'         => __('Title', 'ibx-wpfomo'),
                                        'default'       => '',
                                    ),
                                    'name'              => array(
                                        'type'          => 'text',
                                        'label'         => __('Name', 'ibx-wpfomo'),
                                        'default'       => '',
                                    ),
                                    'email'           => array(
                                        'type'          => 'text',
                                        'label'         => __('Email Address', 'ibx-wpfomo'),
                                    ),
                                    'image'         => array(
                                        'type'          => 'photo',
                                        'label'         => __('Image', 'ibx-wpfomo'),
                                        'help'          => __('Use this field to override the image settings defined under Config tab -> Image Options.', 'ibx-wpfomo')
                                    ),
                                    'url'               => array(
                                        'type'              => 'text',
                                        'label'             => __('URL', 'ibx-wpfomo'),
                                        'default'           => '',
                                        'sanitize_custom'   => 'esc_url'
                                    ),
                                    'rating'    => array(
                                        'type'      => 'select',
                                        'label'     => __('Rating', 'ibx-wpfomo'),
                                        'default'   => '',
                                        'options'   => array(
                                            '5'         => 5,
                                            '4'         => 4,
                                            '3'         => 3,
                                            '2'         => 2,
                                            '1'         => 1,
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'countdown' => array(
                        'title'     => __('Countdown Timer', 'ibx-wpfomo'),
                        'fields'    => array(
                            'enable_countdown' => array(
                                'type'              => 'checkbox',
                                'label'             => __('Enable Countdown?', 'ibx-wpfomo'),
                                'default'           => '0',
                                'sanitize'          => false,
                                'toggle'            => array(
                                    '1'                 => array(
                                        'fields'            => array('countdown_text', 'countdown_time' )
                                    ),
                                ),
                            ),
                            'countdown_text'   => array(
                                'type'              => 'text',
                                'label'             => __('Countdown Text', 'ibx-wpfomo'),
                            ),
                            'countdown_time'   => array(
                                'type'              => 'time',
                                'label'             => __('Countdown Time', 'ibx-wpfomo'),
                            ),
                        )
                    )
                ),
            ),
            'design' => array(
                'title'     => __('Design', 'ibx-wpfomo'),
                'sections'  => array(
                    'design' => array(
                        'title'         => __('Design', 'ibx-wpfomo'),
                        'fields'        => array(
                            'position'      => array(
                                'type'      => 'select',
                                'label'     => __('Positon', 'ibx-wpfomo'),
                                'default'   => 'bottom-left',
                                'options'   => array(
                                    'bottom-left'   => __('Bottom Left', 'ibx-wpfomo'),
                                    'bottom-right'  => __('Bottom Right', 'ibx-wpfomo'),
                                ),
                            ),
                            'position_fomo_bar' => array(
                                'type'      => 'select',
                                'label'     => __('Position', 'ibx-wpfomo'),
                                'default'   => 'top',
                                'options'   => array(
                                    'top'       => __('Top', 'ibx-wpfomo'),
                                    'bottom'    => __('Bottom', 'ibx-wpfomo'),
                                ),
                            ),
                            'text_color'    => array(
                                'type'      => 'color',
                                'label'     => __('Text Color', 'ibx-wpfomo'),
                                'default'   => '#000000',
                            ),
                            'background_color'  => array(
                                'type'          => 'color',
                                'label'         => __('Background Color', 'ibx-wpfomo'),
                                'default'       => '#ffffff',
                            ),
                            'countdown_text_color'    => array(
                                'type'                  => 'color',
                                'label'                 => __('Countdown Text Color', 'ibx-wpfomo'),
                                'default'               => '#000000',
                            ),
                            'countdown_background_color'  => array(
                                'type'                      => 'color',
                                'label'                     => __('Countdown Background Color', 'ibx-wpfomo'),
                                'default'                   => '#eeeeee',
                            ),
                            'link_color'  => array(
                                'type'          => 'color',
                                'label'         => __('Link Color', 'ibx-wpfomo'),
                                'default'       => '#000000',
                            ),
                            'star_color'      => array(
                                'type'          => 'color',
                                'label'         => __('Rating Star Color', 'ibx-wpfomo'),
                                'default'       => '#000000',
                            ),
                            'round_corners'  => array(
                                'type'          => 'number',
                                'label'         => __('Box Round Corners', 'ibx-wpfomo'),
                                'default'       => '0',
                                'description'   => 'px',
                            ),
                            'img_round_corners'  => array(
                                'type'          => 'number',
                                'label'         => __('Image Round Corners', 'ibx-wpfomo'),
                                'default'       => '100',
                                'description'   => 'px',
                            ),
                        ),
                    ),
                    'border'    => array(
                        'title'     => __('Border', 'ibx-wpfomo'),
                        'fields'    => array(
                            'border'  => array(
                                'type'          => 'number',
                                'label'         => __('Border Stroke', 'ibx-wpfomo'),
                                'default'       => '1',
                                'description'   => 'px',
                            ),
                            'border_color'  => array(
                                'type'          => 'color',
                                'label'         => __('Color', 'ibx-wpfomo'),
                                'default'       => '#dddddd',
                            ),
                        )
                    ),
                    'box_shadow'    => array(
                        'title'         => __('Shadow', 'ibx-wpfomo'),
                        'fields'        => array(
                            'shadow_blur'  => array(
                                'type'          => 'number',
                                'label'         => __('Blur', 'ibx-wpfomo'),
                                'default'       => '0',
                                'description'   => 'px',
                            ),
                            'shadow_spread'  => array(
                                'type'          => 'number',
                                'label'         => __('Spread', 'ibx-wpfomo'),
                                'default'       => '0',
                                'description'   => 'px',
                            ),
                            'shadow_color'  => array(
                                'type'          => 'color',
                                'label'         => __('Color', 'ibx-wpfomo'),
                                'default'       => '#999999',
                            ),
                            'shadow_opacity'  => array(
                                'type'          => 'number',
                                'label'         => __('Opacity', 'ibx-wpfomo'),
                                'default'       => '30',
                                'description'   => '%',
                                'size'          => 5
                            ),
                        )
                    ),
                    'button_style' => array(
                        'title'     => __('Button', 'ibx-wpfomo'),
                        'fields'    => array(
                            'button_bg_color'   => array(
                                'type'              => 'color',
                                'label'             => __('Background Color', 'ibx-wpfomo'),
                                'default'           => '#333333'
                            ),
                            'button_bg_hover_color'   => array(
                                'type'              => 'color',
                                'label'             => __('Background Hover Color', 'ibx-wpfomo'),
                                'default'           => '#000000'
                            ),
                            'button_text_color' => array(
                                'type'              => 'color',
                                'label'             => __('Text Color', 'ibx-wpfomo'),
                                'default'           => '#ffffff'
                            ),
                            'button_text_hover_color' => array(
                                'type'              => 'color',
                                'label'             => __('Text Hover Color', 'ibx-wpfomo'),
                                'default'           => '#ffffff'
                            ),
                            'button_border' => array(
                                'type'          => 'number',
                                'label'         => __('Border Width', 'ibx-wpfomo'),
                                'default'       => '0',
                                'description'   => 'px'
                            ),
                            'button_border_color' => array(
                                'type'              => 'color',
                                'label'             => __('Border Color', 'ibx-wpfomo'),
                                'default'           => '#333333'
                            ),
                            'button_border_hover_color' => array(
                                'type'              => 'color',
                                'label'             => __('Border Hover Color', 'ibx-wpfomo'),
                                'default'           => '#000000'
                            ),
                            'button_border_radius'  => array(
                                'type'          => 'number',
                                'label'         => __('Round Corners', 'ibx-wpfomo'),
                                'default'       => '4',
                                'description'   => 'px'
                            )
                        )
                    ),
                ),
            ),
            'visibility' => array(
                'title'     => __('Visibility', 'ibx-wpfomo'),
                'sections'  => array(
                    'visibility' => array(
                        'title'             => __('Visibility', 'ibx-wpfomo'),
                        'fields'            => array(
                            'show_on'          => array(
                                'type'          => 'select',
                                'label'         => __('Show On?', 'ibx-wpfomo'),
                                'default'       => __('everywhere', 'ibx-wpfomo'),
                                'options'       => array(
                                    'everywhere'    => __('Show everywhere', 'ibx-wpfomo'),
                                    'selected'      => __('Show on selected', 'ibx-wpfomo'),
                                    'hide'          => __('Hide on selected', 'ibx-wpfomo')
                                ),
                                'toggle'        => array(
                                    'selected'      => array(
                                        'fields'        => array('global_locations', 'custom_locations', 'page_urls')
                                    ),
                                    'hide'      => array(
                                        'fields'        => array('global_locations', 'custom_locations', 'page_urls')
                                    ),
                                ),
                            ),
                            'global_locations'  => array(
                                'type'              => 'suggest',
                                'label'             => __('Global Locations', 'ibx-wpfomo'),
                                'placeholder'       => __('Choose location...', 'ibx-wpfomo'),
                                'action'            => 'get_locations',
                                'options'           => array(
                                    'type'              => 'global'
                                )
                            ),
                            'custom_locations'  => array(
                                'type'              => 'suggest',
                                'label'             => __('Custom Locations', 'ibx-wpfomo'),
                                'placeholder'       => __('Choose location...', 'ibx-wpfomo'),
                                'action'            => 'get_locations',
                                'options'           => array(
                                    'type'              => 'custom'
                                )
                            ),
                            'page_urls' => array(
                                'type'      => 'textarea',
                                'label'     => __('Target by URL(s)', 'ibx-wpfomo'),
                                'default'   => '',
                                'rows'      => 5,
                                'help'      => __('Enter one location fragment per line. Use * character as a wildcard. Example: category/peace/* to target all posts in category peace.', 'ibx-wpfomo')
                            ),
                            'visibility_display'=> array(
                                'type'              => 'select',
                                'label'             => __('Display', 'ibx-wpfomo'),
                                'default'           => 'always',
                                'options'           => array(
                                    'always'            => __('Always', 'ibx-wpfomo'),
                                    'logged_out'        => __('Logged Out User', 'ibx-wpfomo'),
                                    'logged_in'         => __('Logged In User', 'ibx-wpfomo')
                                ),
                            ),
                            'visibility_visitors'=> array(
                                'type'               => 'select',
                                'label'              => __('Visitors', 'ibx-wpfomo'),
                                'default'            => 'all',
                                'options'            => array(
                                    'all'                => __('All Visitors', 'ibx-wpfomo'),
                                    'new'                => __('New Visitors Only', 'ibx-wpfomo'),
                                    'returning'          => __('Returning Visitors Only', 'ibx-wpfomo')
                                ),
                            ),
                        ),
                    ),
                    'behavior' => array(
                        'title'     => __('Behavior', 'ibx-wpfomo'),
                        'fields'    => array(
                            'initial_delay'   => array(
                                'type'              => 'number',
                                'label'             => __('Initial Delay', 'ibx-wpfomo'),
                                'default'           => __('5', 'ibx-wpfomo'),
                                'description'       => __('seconds', 'ibx-wpfomo'),
                                'help'              => __('Initial delay of displaying first notification.', 'ibx-wpfomo'),
                            ),
                            'max_per_page'   => array(
                                'type'              => 'number',
                                'label'             => __('Max Per Page', 'ibx-wpfomo'),
                                'default'           => __('5', 'ibx-wpfomo'),
                                'help'              => __('Limit the number of notifications to be displayed per page.', 'ibx-wpfomo'),
                            ),
                            'auto_hide' => array(
                                'type'          => 'checkbox',
                                'label'         => __('Auto Hide?', 'ibx-wpfomo'),
                                'default'       => '0',
                                'description'   => __('If checked, fomo bar will be hidden after the time set below.', 'ibx-wpfomo')
                            ),
                            'display_time'   => array(
                                'type'              => 'number',
                                'label'             => __('Hide After', 'ibx-wpfomo'),
                                'default'           => __('6', 'ibx-wpfomo'),
                                'description'       => __('seconds', 'ibx-wpfomo'),
                                'help'              => __('Hide the notification after the time given here.', 'ibx-wpfomo'),
                            ),
                            'delay_between'   => array(
                                'type'              => 'number',
                                'label'             => __('Delay between notifications', 'ibx-wpfomo'),
                                'default'           => __('12', 'ibx-wpfomo'),
                                'description'       => __('seconds', 'ibx-wpfomo'),
                                'help'              => __('Delay between each notifications.', 'ibx-wpfomo'),
                            ),
                            // 'randomize'   => array(
                            //     'type'              => 'checkbox',
                            //     'label'             => __('Randomize notifications', 'ibx-wpfomo'),
                            //     'description'       => __('Makes notifications seem more lifelike by randomizing them.', 'ibx-wpfomo'),
                            // ),
                            'closable'   => array(
                                'type'              => 'checkbox',
                                'label'             => __('Show Close Button', 'ibx-wpfomo'),
                                'description'       => __('Display close button at the top right corner.', 'ibx-wpfomo'),
                            ),
                            'loop'   => array(
                                'type'              => 'checkbox',
                                'label'             => __('Loop notification', 'ibx-wpfomo'),
                                'description'       => __('Repeats the sequence of your notifications, if visitor still on page when they run out.', 'ibx-wpfomo'),
                            ),
                            'link_target'   => array(
                                'type'              => 'checkbox',
                                'label'             => __('Open link in new tab', 'ibx-wpfomo'),
                                'description'       => __('When a user clicks on the notifications the link will open in new tab.', 'ibx-wpfomo'),
                            ),
                        ),
                    ),
                    'display_setting' => array(
                        'title'     => __('Display', 'ibx-wpfomo'),
                        'fields'    => array(
                            'hide_mobile'   => array(
                                'type'              => 'checkbox',
                                'label'             => __('Hide on Mobile', 'ibx-wpfomo'),
                                'description'       => __('It will disable this on mobile screen.', 'ibx-wpfomo'),
                            ),
                            'hide_desktop'   => array(
                                'type'              => 'checkbox',
                                'label'             => __('Hide on Desktop', 'ibx-wpfomo'),
                                'description'       => __('It will disable this on desktop screen.', 'ibx-wpfomo'),
                            ),
                        ),
                    ),
                ),
            ),
            'tracking'  => array(
                'title'     => __('Tracking', 'ibx-wpfomo'),
                'sections'  => array(
                    'campaign'  => array(
                        'title'         => __('Campaign Information', 'ibx-wpfomo'),
                        'description'   => __('This settings allows you to easily add campaign parameters to URLs so you can track Custom Campaigns in Google Analytics.', 'ibx-wpfomo'),
                        'fields'    => array(
                            'utm_source'    => array(
                                'type'          => 'text',
                                'label'         => __('Campaign Source', 'ibx-wpfomo'),
                                'default'       => '',
                                'help'          => __('Identify the advertiser, site, publication, etc. that is sending traffic to your property, for example: google, newsletter4, billboard.', 'ibx-wpfomo')
                            ),
                            'utm_medium'    => array(
                                'type'          => 'text',
                                'label'         => __('Marketing Medium', 'ibx-wpfomo'),
                                'default'       => '',
                                'help'          => __('The advertising or marketing medium, for example: cpc, banner, email newsletter.', 'ibx-wpfomo')
                            ),
                            'utm_campaign'  => array(
                                'type'          => 'text',
                                'label'         => __('Campaign Name', 'ibx-wpfomo'),
                                'default'       => '',
                                'help'          => __('The individual campaign name, slogan, promo code, etc. for a product.', 'ibx-wpfomo')
                            ),
                            'utm_term'      => array(
                                'type'          => 'text',
                                'label'         => __('Campaign Term', 'ibx-wpfomo'),
                                'default'       => '',
                                'description'   => __('(Optional)', 'ibx-wpfomo'),
                                'help'          => __('Identify paid search keywords. If you\'re manually tagging paid keyword campaigns, you should also use this field to specify the keyword.', 'ibx-wpfomo')
                            ),
                        )
                    )
                )
            )
        ) )
    );
}

do_action( 'ibx_wpfomo_before_metabox_load' );

MetaBox_Tabs::add_meta_box( ibx_wpfomo_metabox_args() );
