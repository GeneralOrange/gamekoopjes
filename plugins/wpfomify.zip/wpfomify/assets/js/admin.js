/**
 * WPfomify Admin Script
 * @since 1.0.0
 */
;(function($) {

    /* Trigger some events on load */
    $(window).load(function() {
        setTimeout(function() {

            $('#ibx_wpfomo_type').on('change', function() {
                // Hide notification preview.
                if ( $(this).val() === 'fomo_bar' || $(this).val() === 'floating_button' ) {
                    $('.ibx-notification-popup').hide();
                    $('#ibx_wpfomo_fb_icon_source').trigger('change');
                    if ( $(this).val() === 'floating_button' ) {
                        $('.ibx-wpfomo-floating-button-wrap').show();
                    }
                } else {
                    $('.ibx-notification-popup').removeClass('ibx-notification-type-reviews').removeClass('ibx-notification-type-conversion');
                    $('.ibx-notification-popup').show().addClass('ibx-notification-type-' + $(this).val());
                    $('.ibx-wpfomo-floating-button-wrap').hide();
                }

                if ( $(this).val() === 'conversion' ) {
                    $('#ibx_wpfomo_conversions_source').trigger('change');
                    $('#ibx_wpfomo_woo_product_link').trigger('change');
                    $('#ibx_wpfomo_edd_product_link').trigger('change');
                    $('#ibx_wpfomo_ld_product_link').trigger('change');
                }
            });

            $('#ibx_wpfomo_conversions_source').on('change', function() {
                $('#ibx_wpfomo_woo_product_link').trigger('change');
                $('#ibx_wpfomo_edd_product_link').trigger('change');
                $('#ibx_wpfomo_ld_product_link').trigger('change');
            });

            $('#ibx_wpfomo_type').trigger('change');
            $('#ibx_wpfomo_fb_icon_source').trigger('change');
        }, 100);
    });

    $(document).ready(function() {
        /* Post Columns - Active/Inactive toggle */
        $('.wp-list-table .column-notification_status img').off('click').on('click', function(e) {
            e.stopPropagation();

            var $this       = $(this),
                isActive    = $(this).attr('src').indexOf('active1.png') >= 0,
                postID      = $(this).data('post'),
                nonce       = $(this).data('nonce');

            if ( isActive ) {
                $this.attr('src', $this.attr('src').replace('active1.png', 'active0.png'));
                $this.attr('title', 'Inactive').attr('alt', 'Inactive');
            } else {
                $this.attr('src', $this.attr('src').replace('active0.png', 'active1.png'));
                $this.attr('title', 'Active').attr('alt', 'Active');
            }

            $.ajax({
                type: 'post',
                url: ajaxurl,
                data: {
                    action: 'ibx_wpfomo_toggle_status',
                    post_id: postID,
                    nonce: nonce,
                    status: isActive ? 'inactive' : 'active'
                },
                success: function(res) {
                    if ( res !== 'success' ) {
                        alert( res );
                        isActive = $this.attr('src').indexOf('active1.png') >= 0;
                        if ( isActive ) {
                            $this.attr('src', $this.attr('src').replace('active1.png', 'active0.png'));
                            $this.attr('title', 'Inactive').attr('alt', 'Inactive');
                        } else {
                            $this.attr('src', $this.attr('src').replace('active0.png', 'active1.png'));
                            $this.attr('title', 'Active').attr('alt', 'Active');
                        }
                    }
                }
            });
        });

        /* Preview */
        IBXFomoPreview.init([
            // Text color
            {
                type: 'color',
                field: '#ibx_wpfomo_text_color',
                selector: '.ibx-notification-popup, .ibx-notification-popup .ibx-notification-popup-close',
                property: 'color'
            },
            // Background color
            {
                type: 'color',
                field: '#ibx_wpfomo_background_color',
                selector: '.ibx-notification-popup',
                property: 'background'
            },
            // Link color
            {
                type: 'color',
                field: '#ibx_wpfomo_link_color',
                selector: '.ibx-notification-popup .ibx-notification-popup-title',
                property: 'color'
            },
            // Ratings color
            {
                type: 'color',
                field: '#ibx_wpfomo_star_color',
                selector: '.ibx-notification-popup .ibx-notification-popup-rating span',
                property: 'color'
            },
            // Round Corners
            {
                type: 'number',
                field: '#ibx_wpfomo_round_corners',
                selector: '.ibx-notification-popup',
                property: 'border-radius',
                unit: 'px'
            },
            // Image Round Corners
            {
                type: 'number',
                field: '#ibx_wpfomo_img_round_corners',
                selector: '.ibx-notification-popup .ibx-notification-popup-img img',
                property: 'border-radius',
                unit: 'px'
            },
            // Border width
            {
                type: 'number',
                field: '#ibx_wpfomo_border',
                selector: '.ibx-notification-popup',
                property: 'border-width',
                unit: 'px'
            },
            // Border color
            {
                type: 'color',
                field: '#ibx_wpfomo_border_color',
                selector: '.ibx-notification-popup',
                property: 'border-color'
            },
            // Box Shadow
            {
                type: 'box-shadow',
                field: {
                    blur: '#ibx_wpfomo_shadow_blur',
                    spread: '#ibx_wpfomo_shadow_spread',
                    color: '#ibx_wpfomo_shadow_color',
                    opacity: '#ibx_wpfomo_shadow_opacity'
                },
                selector: '.ibx-notification-popup',
                property: 'box-shadow'
            },
        ]);
    });
})(jQuery);
