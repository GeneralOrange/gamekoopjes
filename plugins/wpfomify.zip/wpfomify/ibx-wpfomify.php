<?php
/*
 * Plugin Name: WPfomify
 * Plugin URI: https://wpfomify.com
 * Version: 1.2
 * Description: Social Proof Marketing Plugin for WordPress.
 * Author: IdeaBox Creations
 * Author URI: https://ideaboxcreations.com
 * Copyright: (c) 2017 IdeaBox Creations
 * License: GNU General Public License v2.0
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ibx-wpfomo
*/

define( 'IBX_WPFOMO_VER', '1.2' );
define( 'IBX_WPFOMO_DIR', plugin_dir_path( __FILE__ ) );
define( 'IBX_WPFOMO_URL', plugins_url( '/', __FILE__ ) );
define( 'IBX_WPFOMO_PATH', plugin_basename( __FILE__ ) );

require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-helper.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-cron.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-admin.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-ajax.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-frontend.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-floatingbutton.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-api.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-addons.php';
require_once IBX_WPFOMO_DIR . 'classes/class-ibx-wpfomo-addon.php';

require_once IBX_WPFOMO_DIR . 'includes/updater/updater-config.php';

?>
