<?php foreach ($warnings as $msg): ?>
	<div class="error"><p><?php echo $msg ?></p></div>
<?php endforeach ?>