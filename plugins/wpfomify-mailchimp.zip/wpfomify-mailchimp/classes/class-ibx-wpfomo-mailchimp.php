<?php

class IBX_WPFomo_MailChimp_Helper {
	/**
	 * @since 1.0.0
	 * @var object $api_instance
	 * @access private
	 */
	static private $api_instance = null;

	/**
	 * Get an instance of the API.
	 *
	 * @since 1.0.0
	 * @param string $api_key A valid API key.
	 * @return object The API instance.
	 */
	static public function get_api( $api_key )
	{
		if ( self::$api_instance ) {
			return self::$api_instance;
		}
		if ( ! class_exists( 'Mailchimp' ) ) {
			require_once IBX_WPFOMO_MAILCHIMP_DIR . 'includes/vendor/mailchimp/mailchimp.php';
		}

		self::$api_instance = new Mailchimp( $api_key );

		return self::$api_instance;
	}

    /**
	 * Test the API connection.
	 *
	 * @since 1.0.0
	 * @param array $fields {
	 *      @type string $api_key A valid API key.
	 * }
	 * @return array{
	 *      @type bool|string $error The error message or false if no error.
	 *      @type array $data An array of data used to make the connection.
	 * }
	 */
	static public function connect( $api_key = '' )
	{
		$response = array(
			'error'  => false,
			'data'   => array()
		);

		// Make sure we have an API key.
		if ( empty( $api_key ) ) {
			$response['error'] = __( 'Error: You must provide an API key.', 'ibx-wpfomo' );
		}
		// Try to connect and store the connection data.
		else {

			$api = self::get_api( $api_key );

			try {
				$api->helper->ping();
				$response['data'] = array( 'api_key' => $api_key );
			}
			catch ( Mailchimp_Invalid_ApiKey $e ) {
				$response['error'] = $e->getMessage();
			}
            catch ( Mailchimp_Error $e ) {
                $response['error'] = $e->getMessage();
            }
		}

		return $response;
	}

    static public function get_members( $api_key = '', $list_id = '', $limit = 100 )
    {
        $response = array(
			'error'      => false,
			'members'    => array()
		);

        // Make sure we have an API key.
		if ( empty( $api_key ) ) {
			$response['error'] = __( 'Error: You must provide an API key.', 'ibx-wpfomo' );
		}

        // Make sure we have list id.
		if ( empty( $list_id ) ) {
			$response['error'] = __( 'Error: You must provide a list ID.', 'ibx-wpfomo' );
		}

        if ( ! $response['error'] ) {
            $api = self::get_api( $api_key );

            try {
                $members = $api->lists->members( $list_id, 'subscribed', array( 'limit' => $limit, 'sort_field' => 'optin_time', 'sort_dir' => 'DESC' ) );
                $response['members'] = $members;
            }
            catch ( Mailchimp_HttpError $e ) {
                $response['error'] = $e->getMessage();
            }
        }

        return $response;
    }
}
