<?php
/*
 * Plugin Name: WPfomify - MailChimp Add-on
 * Plugin URI: https://wpfomify.com
 * Version: 1.0.1
 * Description: MainChimp Add-on for WPfomify - The Social Proof Marketing plugin for WordPress
 * Author: IdeaBox Creations
 * Author URI: https://ideaboxcreations.com
 * Copyright: (c) 2016 IdeaBox Creations
 * License: GNU General Public License v2.0
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ibx-wpfomo
 */

define( 'IBX_WPFOMO_MAILCHIMP_VER', '1.0.1' );
define( 'IBX_WPFOMO_MAILCHIMP_DIR', plugin_dir_path( __FILE__ ) );
define( 'IBX_WPFOMO_MAILCHIMP_URL', plugins_url( '/', __FILE__ ) );
define( 'IBX_WPFOMO_MAILCHIMP_PATH', plugin_basename( __FILE__ ) );

class IBX_WPFomo_MailChimp {
    /**
     * Holds the class object.
     *
     * @since 1.0.0
     * @var object
     */
    public static $instance;

    /**
     * Primary class constructor.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        add_action( 'plugins_loaded', array( $this, 'init_hooks' ) );
        add_action( 'admin_init', array( $this, 'plugin_updater' ), 0 );
        add_filter( 'ibx_wpfomo_admin_general_settings', array( $this, 'register_admin_settings' ), 10, 1 );
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     */
    public function init_hooks()
    {
        require_once IBX_WPFOMO_MAILCHIMP_DIR . 'classes/class-ibx-wpfomo-mailchimp.php';

        add_action( 'ibx_wpfomo_before_metabox_load', array( $this, 'init_fields' ) );
        add_action( 'ibx_wpfomo_admin_meta_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'ibx_wpfomo_admin_settings_scripts', array( $this, 'enqueue_scripts' ) );
        add_filter( 'ibx_wpfomo_conversion_data', array( $this, 'add_conversion_data' ), 10, 2 );
        add_action( 'wp_ajax_ibx_wpfomo_connect_mailchimp', array( $this, 'connect_mailchimp' ) );
        add_action( 'save_post', array( $this, 'schedule_event' ) );
    }

    /**
     * Plugin updater.
     *
     * @since 1.0.0
     */
    public function plugin_updater() {

        if ( ! class_exists( 'IBX_WPFomo_Plugin_Updater' ) ) {
            return;
        }

    	$license_key = trim( get_option( 'ibx_wpfomo_license_key' ) );

    	// setup the updater
    	$updater = new IBX_WPFomo_Plugin_Updater( IBX_WPFOMO_SL_URL, __FILE__, array(
                'version' 	=> IBX_WPFOMO_MAILCHIMP_VER, // current version number
                'license' 	=> $license_key, // license key
                'item_id'   => 121, // id of this addon
    			'item_name' => 'MailChimp Addon', 	// name of this addon
    			'author' 	=> 'IdeaBox Creations',  // author of this addon
    			'beta'		=> false
    		)
    	);
    }

    /**
     * Init fields for MailChimp integration.
     *
     * @since 1.0.0
     * @return void
     */
    public function init_fields()
    {
        add_filter( 'ibx_wpfomo_field_fomo_type', array( $this, 'hide_fields' ), 10, 1 );
        add_filter( 'ibx_wpfomo_field_conversions_source', array( $this, 'conversion_source' ), 10, 1 );
        add_filter( 'ibx_wpfomo_metabox_fields', array( $this, 'add_fields' ), 10, 1 );
    }

    /**
     * Enqueue style and scripts.
     *
     * @since 1.0.0
     * @return void
     */
    public function enqueue_scripts()
    {
        wp_enqueue_style( 'ibx-wpfomo-mailchimp-style', IBX_WPFOMO_MAILCHIMP_URL . 'assets/css/main.css' );
        wp_enqueue_script( 'ibx-wpfomo-mailchimp-script', IBX_WPFOMO_MAILCHIMP_URL . 'assets/js/main.js', array('jquery'), true );
        wp_localize_script( 'ibx-wpfomo-mailchimp-script', 'wpfomo_mailchimp', array(
            'messages'  => array(
                'connect_success'   => __('Connected successfully! Lists data has been fetched.', 'ibx-wpfomo')
            )
        ) );
    }

    /**
     * Register admin settings.
     *
     * @since 1.0.0
     * @param array $settings
     * @return array
     */
    public function register_admin_settings( $settings )
    {
        $settings['sections']['mailchimp_api_key'] = array(
            'title'     => 'MailChimp',
            'fields'    => array(
                'mailchimp_api_key' => array(
                    'type'              => 'text',
                    'label'             => __('API Key', 'ibx-wpfomo'),
                    'default'           => '',
                    'help'              => __( 'Enter your API key and press "Connect" below. Your API key can be found in your MailChimp account under Account > Extras > API Keys.', 'ibx-wpfomo' )
                ),
                'mailchimp_connect' => array(
                    'type'              => 'button',
                    'label'             => __('Connect', 'ibx-wpfomo'),
                    'class'             => 'ibx-wpfomo-mailchimp-connect'
                ),
            )
        );

        $lists = get_option( 'ibx_wpfomo_mailchimp_lists' );

        if ( $lists && ! empty( $lists ) ) {
            $settings['sections']['mailchimp_api_key']['fields']['mailchimp_connect']['label'] = __('Refresh Lists', 'ibx-wpfomo');
        }

        return $settings;
    }

    /**
     * Connect mailchimp via AJAX request.
     *
     * @since 1.0.0
     * @return void
     */
    public function connect_mailchimp()
    {
        $response = array(
			'error'  => false,
			'html'   => ''
		);

        if ( ! isset( $_POST['api_key'] ) || empty( $_POST['api_key'] ) ) {
            $response['error'] = __('Error: You must provide an API key.', 'ibx-wpfomo');
        }

        if ( ! $response['error'] ) {

            $api_key = $_POST['api_key'];
            $connection = IBX_WPFomo_MailChimp_Helper::connect( $api_key );

            if ( $connection['error'] ) {
                $response['error'] = $connection['error'];
            }
            else {
                $post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : '';
                $list_id = false;

                if ( ! empty( $post_id ) ) {
                    $list_id = get_post_meta( $post_id, 'ibx_wpfomo_mailchimp_list', true );
                }

                $api = IBX_WPFomo_MailChimp_Helper::get_api( $api_key );

                // Lists field html.
        		try {
                    $lists = $api->lists->getList();

                    if ( ! empty( $post_id ) ) {
                        $response['html'] .= $this->list_field_html( $lists, $list_id );
                    }

                    update_option( 'ibx_wpfomo_mailchimp_lists', $lists );
        		}
        		catch ( Mailchimp_Error $e ) {
        			$response['error'] = $e->getMessage();
        		}
            }
        }

        echo json_encode( $response ); die();
    }

    /**
     * HTML to render in list field.
     *
     * @since 1.0.0
     * @return void
     */
    private function list_field_html( $lists, $list_id )
    {
        ob_start();
        ?>
        <option value=""><?php _e('Choose...', 'ibx-wpfomo'); ?></option>

        <?php foreach ( $lists['data'] as $list ) { ?>
            <option value="<?php echo $list['id']; ?>"<?php echo $list_id == $list['id'] ? ' selected="selected"' : ''; ?>><?php echo $list['name']; ?></option>
		<?php } ?>

        <?php
        return ob_get_clean();
    }

    /**
     * Get lists from saved option.
     *
     * @since 1.0.0
     * @return array
     */
    public function get_list_options()
    {
        $lists = get_option( 'ibx_wpfomo_mailchimp_lists' );
        $options = array();

        if ( is_array( $lists ) && ! empty( $lists ) ) {
            foreach ( $lists['data'] as $list ) {
                $options[$list['id']] = $list['name'];
            }
        }

        return $options;
    }

    /**
     * Mailchimp conversion fields.
     *
     * @since 1.0.0
     * @return array
     */
    public function get_fields()
    {
        $fields = array(
            'mailchimp_list'    => array(
                'type'              => 'select',
                'label'             => __('MailChimp List', 'ibx-wpfomo'),
                'default'           => '',
                'options'           => $this->get_list_options()
            ),
            'mailchimp_template'    => array(
                'type'                  => 'textarea',
                'label'                 => __('Notification Template', 'ibx-wpfomo'),
                'rows'                  => 3,
                'default'               => __('{{name}} signed up for {{title}} {{time}}', 'ibx-wpfomo'),
                'help'                  => __('Variables: {{name}}, {{title}}, {{time}}', 'ibx-wpfomo'),
            ),
            'mailchimp_limit'   => array(
                'type'              => 'number',
                'label'             => __('Number of Subscribers', 'ibx-wpfomo'),
                'default'           => 5,
                'help'              => __('Maximum number of subscribers to be displayed.', 'ibx-wpfomo')
            ),
            'mailchimp_link'    => array(
                'type'              => 'text',
                'label'             => __('Link to', 'ibx-wpfomo'),
                'default'           => '',
            )
        );

        return $fields;
    }

    /**
     * Hide fields when reviews is selected.
     *
     * @since 1.0.0
     * @param array $data
     * @return array
     */
    public function hide_fields( $data )
    {
        $fields = $this->get_fields();

        // Hide fields from other field types.
        foreach ( $data['options'] as $option_key => $option_val ) {
            if ( $option_key != 'conversion' ) {
                foreach ( $fields as $key => $field ) {
                    $data['hide'][$option_key]['fields'][] = $key;
                }
            }
        }

        return $data;
    }

    /**
     * Add MailChimp as conversion source.
     *
     * @since 1.0.0
     * @param array $data
     * @return array
     */
    public function conversion_source( $data )
    {
        $data['options']['mailchimp'] = 'MailChimp';
        $data['toggle']['mailchimp']['fields'] = array_keys( $this->get_fields() );

        return $data;
    }

    /**
     * Add fields for MailChimp conversion.
     *
     * @since 1.0.0
     * @param array $data
     * @return array
     */
    public function add_fields( $data )
    {
        $fields = $this->get_fields();

        foreach ( $fields as $key => $field ) {
            $data['content']['sections']['content_section']['fields'][$key] = $field;
        }

        return $data;
    }

    /**
     * Add conversion content for MailChimp.
     *
     * @since 1.0.0
     * @param array $data
     * @param object $settings
     * @return array
     */
    public function add_conversion_data( $data, $settings )
    {
        if ( 'mailchimp' != $settings->conversions_source ) {
            return $data;
        }

        $limit = $settings->mailchimp_limit;

        if ( empty( $limit ) || ! $limit ) {
            $limit = 100;
        }

        $members = IBX_WPFomo_Admin::get_post_meta( $settings->post_id, 'mailchimp_members' );

        if ( empty( $members ) ) {
            return $data;
        }
        if ( empty( $members['data'] ) || $members['total'] == 0 ) {
            return $data;
        }

        foreach ( $members['data'] as $member ) {

            // Data to render notification.
            $fields_data = array(
                'title'     => $member['list_name'],
                'name'      => $member['merges']['FNAME'],
                'email'     => $member['email'],
                'time'      => ''
            );

            if ( isset( $member['timestamp_opt'] ) && ! empty( $member['timestamp_opt'] ) ) {
                $time = human_time_diff( strtotime( $member['timestamp_opt'] ), time() );
                ob_start();
                ?>
                <small><?php echo esc_html__( 'About', 'ibx-wpfomo' ) . ' ' . esc_html( $time ) . ' ' . esc_html__( 'ago', 'ibx-wpfomo' ) ?></small>
                <?php
                $time_ago = ob_get_clean();

                $fields_data['time'] = $time_ago;
            }

            // Link
            $fields_data['url'] = esc_url( $settings->mailchimp_link );

            $data['fields'][] = $fields_data;
        }

        $data['template'] = $settings->mailchimp_template;

        return $data;
    }

    /**
     * Get saved members from post meta.
     *
     * @since 1.0.0
     * @param int $post_id
     * @return array
     */
    public function get_members( $post_id )
    {
        $conversion_source = IBX_WPFomo_Admin::get_post_meta( $post_id, 'conversions_source' );

        // Return if it's not mailchimp conversion.
        if ( 'mailchimp' != $conversion_source ) {
            return $post_id;
        }

        $list_id = IBX_WPFomo_Admin::get_post_meta( $post_id, 'mailchimp_list' );

        // Return of mailchimp list field is empty.
        if ( ! $list_id || empty( $list_id ) ) {
            return $post_id;
        }

        // Get api key.
        $api_key = IBX_WPFomo_Admin::get_settings( 'mailchimp_api_key' );

        // Return if api key is empty.
        if ( ! $api_key || empty( $api_key ) ) {
            return $post_id;
        }

        // Get limit.
        $limit = IBX_WPFomo_Admin::get_post_meta( $post_id, 'mailchimp_limit' );

        // Set limit to 100 if empty.
        if ( empty( $limit ) || ! $limit ) {
            $limit = 100;
        }

        // Get response from mailchimp.
        $response = IBX_WPFomo_MailChimp_Helper::get_members( $api_key, $list_id, $limit );
        $members = $response['members'];

        return $members;
    }

    /**
     * Cron job to fetch mailchimp subscribers.
     *
     * @since 1.0.0
     * @param int $post_id
     * @return void
     */
    public function schedule_event( $post_id )
    {
        // Verify if this is an auto save routine.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }

        $members = $this->get_members( $post_id );

        // Update fetched members in post meta.
        IBX_WPFomo_Admin::update_post_meta( $post_id, 'mailchimp_members', $members );

        // First clear previously scheduled cron hook.
        wp_clear_scheduled_hook( 'ibx_wpfomo_mailchimp_get_members_cron' );

        // If there is no next event, start cron now.
        if ( ! wp_next_scheduled ( 'ibx_wpfomo_mailchimp_get_members_cron' ) ) {
    	    wp_schedule_event( time(), 'twicedaily', 'ibx_wpfomo_mailchimp_get_members_cron', array( 'post_id' => $post_id ) );
        }

        // Cron hook.
        add_action( 'ibx_wpfomo_mailchimp_get_members_cron', array( $this, 'schedule_members' ) );
    }

    /**
     * Cron job to fetch mailchimp subscribers.
     *
     * @since 1.0.0
     * @param array $args
     * @return void
     */
    public function schedule_members( $args = array() )
    {
        if ( empty( $args ) ) {
            return;
        }

        $post_id = $args['post_id'];

        $members = $this->get_members( $post_id );

        // Update fetched members in post meta.
        IBX_WPFomo_Admin::update_post_meta( $post_id, 'mailchimp_members', $members );
    }

    /**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 * @return object The IBX_WPFomo_MailChimp object.
	 */
	public static function get_instance()
	{
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof IBX_WPFomo_MailChimp ) ) {
			self::$instance = new IBX_WPFomo_MailChimp();
		}

		return self::$instance;
	}
}

$ibx_wpfomo_mailchimp = IBX_WPFomo_MailChimp::get_instance();
