;(function($) {
    $(document).ready(function() {
        $('.ibx-wpfomo-mailchimp-connect').on('click', function() {
            var apiKey      = $('#ibx_wpfomo_mailchimp_api_key').val(),
                listField   = $('#ibx_wpfomo_mailchimp_list'),
                self        = $(this),
                loader      = self.parent().find('.mbt-loader'),
                postID      = $('input[name="post_ID"]').val();

            self.addClass('disabled');
            loader.show();

            $.ajax({
                type: 'post',
                url: ajaxurl,
                data: {
                    action: 'ibx_wpfomo_connect_mailchimp',
                    api_key: apiKey,
                    post_id: postID
                },
                success: function(response) {
                    var data = JSON.parse(response);

                    if ( data.error ) {
                        self.after( '<div class="ibx-wpfomo-error-message">' + data.error + '</div>' );
                    }
                    else {
                        self.parent().find('.ibx-wpfomo-error-message').remove();
                        self.after( '<div class="ibx-wpfomo-success-message">' + wpfomo_mailchimp.messages.connect_success + '</div>' );
                        //listField.html( data.html );
                    }

                    self.removeClass('disabled');
                    loader.hide();
                }
            });
        });

        $(window).load(function() {
            //$('.ibx-wpfomo-mailchimp-connect').trigger('click');
        });
    });
})(jQuery);
